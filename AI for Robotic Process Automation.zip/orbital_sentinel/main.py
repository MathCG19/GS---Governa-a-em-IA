"""
╔══════════════════════════════════════════════════════════════════╗
║          ORBITAL SENTINEL — AI for RPA · FIAP GS 2026           ║
║   Sistema Automatizado de Monitoramento de Missões Espaciais     ║
╚══════════════════════════════════════════════════════════════════╝

Pipeline RPA que integra:
  1. Web Scraping (BeautifulSoup4) — coleta dados de missões da NASA API
  2. REST API (requests)           — consome Open Notify e NASA APIs
  3. IA / NLP (Claude API)         — análise inteligente dos dados
  4. Planilhas (openpyxl)          — exportação estruturada para Excel
  5. Agendamento (schedule)        — execução automática periódica
  6. Logs / Arquivos               — rastreabilidade completa

Autor: FIAP GS 2026 — AI for RPA
"""

import os
import json
import logging
import time
import schedule
import requests
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from bs4 import BeautifulSoup
from datetime import datetime
from pathlib import Path
from google import genai as google_genai

# ─────────────────────────────────────────────
# CONFIGURAÇÕES GLOBAIS
# ─────────────────────────────────────────────
BASE_DIR      = Path(__file__).parent
DATA_DIR      = BASE_DIR / "data"
OUTPUT_DIR    = BASE_DIR / "outputs"
LOG_DIR       = BASE_DIR / "logs"
REPORT_DIR    = BASE_DIR / "reports"

NASA_API_KEY  = "DEMO_KEY"   # Substitua por sua chave em api.nasa.gov (gratuita)
GEMINI_MODEL  = "gemini-2.5-flash"   # Modelo gratuito do Google

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DE LOGGING
# ─────────────────────────────────────────────
log_file = LOG_DIR / f"orbital_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("OrbitalSentinel")


# ══════════════════════════════════════════════════════════════════
# MÓDULO 1 — REST API: Coleta de dados via APIs públicas espaciais
# ══════════════════════════════════════════════════════════════════
class SpaceAPICollector:
    """
    Consome APIs REST públicas de exploração espacial.
    Tópico coberto: REST API + Tratamento de Exceções
    """

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "OrbitalSentinel/1.0 FIAP-GS2026"})

    def _safe_get(self, url: str, params: dict = None, timeout: int = 10) -> dict | None:
        """Requisição GET com tratamento de exceções robusto."""
        try:
            log.info(f"[API] GET {url}")
            resp = self.session.get(url, params=params, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.Timeout:
            log.error(f"[API] Timeout ao acessar {url}")
        except requests.exceptions.HTTPError as e:
            log.error(f"[API] Erro HTTP {e.response.status_code}: {url}")
        except requests.exceptions.ConnectionError:
            log.error(f"[API] Falha de conexão: {url}")
        except Exception as e:
            log.error(f"[API] Erro inesperado: {e}")
        return None

    def get_people_in_space(self) -> dict:
        """Open Notify API — pessoas atualmente no espaço."""
        data = self._safe_get("http://api.open-notify.org/astros.json")
        if data:
            log.info(f"[API] {data.get('number', 0)} astronautas no espaço encontrados")
            return data
        # Fallback com dados simulados para demonstração
        log.warning("[API] Usando dados de fallback para astronautas")
        return {
            "number": 7,
            "people": [
                {"name": "Oleg Kononenko", "craft": "ISS"},
                {"name": "Nikolai Chub",   "craft": "ISS"},
                {"name": "Tracy Dyson",    "craft": "ISS"},
                {"name": "Matthew Dominick","craft": "ISS"},
                {"name": "Michael Barratt", "craft": "ISS"},
                {"name": "Jeanette Epps",  "craft": "ISS"},
                {"name": "Alexander Grebenkin","craft": "ISS"},
            ],
            "message": "success (fallback)"
        }

    def get_iss_position(self) -> dict:
        """Open Notify API — posição atual da ISS."""
        data = self._safe_get("http://api.open-notify.org/iss-now.json")
        if data:
            pos = data.get("iss_position", {})
            log.info(f"[API] ISS em lat={pos.get('latitude')} lon={pos.get('longitude')}")
            return data
        log.warning("[API] Usando posição de fallback para ISS")
        return {
            "iss_position": {"latitude": "-35.2809", "longitude": "-70.3430"},
            "timestamp": int(time.time()),
            "message": "success (fallback)"
        }

    def get_nasa_apod(self) -> dict:
        """NASA APOD API — Astronomy Picture of the Day."""
        data = self._safe_get(
            "https://api.nasa.gov/planetary/apod",
            params={"api_key": NASA_API_KEY, "count": 5}
        )
        if data and isinstance(data, list):
            log.info(f"[API] {len(data)} imagens APOD coletadas")
            return {"apod_images": data}
        log.warning("[API] Usando dados de fallback para APOD")
        return {
            "apod_images": [
                {
                    "date": "2026-05-01",
                    "title": "Pillars of Creation - Webb Telescope",
                    "explanation": "The Webb Space Telescope captured these towering columns of gas and dust inside the Eagle Nebula, revealing thousands of new stars forming within dense clouds.",
                    "url": "https://apod.nasa.gov/apod/image/2210/PillarsOfCreation2022_Webb.jpg",
                    "media_type": "image"
                },
                {
                    "date": "2026-05-02",
                    "title": "Mars Perseverance Rover Selfie",
                    "explanation": "NASA's Perseverance rover captured a selfie at Jezero Crater, where it continues to search for signs of ancient microbial life and collect rock samples.",
                    "url": "https://apod.nasa.gov/apod/image/2104/PerseveranceSelfie.jpg",
                    "media_type": "image"
                },
                {
                    "date": "2026-05-03",
                    "title": "Artemis I Launch — Return to the Moon",
                    "explanation": "The SLS rocket launched the Orion capsule on its uncrewed journey around the Moon, paving the way for returning humans to the lunar surface.",
                    "url": "https://apod.nasa.gov/apod/image/2211/ArtemisI_launch.jpg",
                    "media_type": "image"
                },
            ]
        }

    def get_near_earth_objects(self) -> dict:
        """NASA NeoWs API — objetos próximos à Terra."""
        today = datetime.now().strftime("%Y-%m-%d")
        data = self._safe_get(
            "https://api.nasa.gov/neo/rest/v1/feed",
            params={"start_date": today, "api_key": NASA_API_KEY}
        )
        if data:
            neos = data.get("near_earth_objects", {})
            total = sum(len(v) for v in neos.values())
            log.info(f"[API] {total} objetos próximos à Terra encontrados")
            return data
        log.warning("[API] Usando dados de fallback para NEO")
        return {
            "element_count": 8,
            "near_earth_objects": {
                datetime.now().strftime("%Y-%m-%d"): [
                    {
                        "name": "2024 XY1",
                        "is_potentially_hazardous_asteroid": False,
                        "estimated_diameter": {"kilometers": {"estimated_diameter_max": 0.12}},
                        "close_approach_data": [{"miss_distance": {"kilometers": "1200000"}, "relative_velocity": {"kilometers_per_second": "12.5"}}]
                    },
                    {
                        "name": "2023 AB3",
                        "is_potentially_hazardous_asteroid": True,
                        "estimated_diameter": {"kilometers": {"estimated_diameter_max": 0.85}},
                        "close_approach_data": [{"miss_distance": {"kilometers": "450000"}, "relative_velocity": {"kilometers_per_second": "18.2"}}]
                    },
                ]
            }
        }


# ══════════════════════════════════════════════════════════════════
# MÓDULO 2 — WEB SCRAPING: Coleta de notícias espaciais
# ══════════════════════════════════════════════════════════════════
class SpaceNewsScraper:
    """
    Faz scraping de notícias de missões espaciais.
    Tópico coberto: BeautifulSoup4 + XPath/CSS Selectors
    """

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (compatible; OrbitalSentinel/1.0)"
        })

    def scrape_spacenews_api(self) -> list[dict]:
        """
        Usa a Spaceflight News API (REST pública) para obter notícias.
        Combinação de REST API + parsing estruturado de dados.
        """
        log.info("[SCRAPER] Coletando notícias espaciais via Spaceflight News API")
        try:
            resp = self.session.get(
                "https://api.spaceflightnewsapi.net/v4/articles/",
                params={"limit": 10, "ordering": "-published_at"},
                timeout=12
            )
            resp.raise_for_status()
            articles = resp.json().get("results", [])
            log.info(f"[SCRAPER] {len(articles)} notícias coletadas com sucesso")
            return [
                {
                    "title":       a.get("title", ""),
                    "summary":     a.get("summary", "")[:300],
                    "published":   a.get("published_at", "")[:10],
                    "source":      a.get("news_site", ""),
                    "url":         a.get("url", ""),
                }
                for a in articles
            ]
        except Exception as e:
            log.warning(f"[SCRAPER] Falha na API de notícias: {e}. Usando dados de fallback.")
            return self._fallback_news()

    def _fallback_news(self) -> list[dict]:
        """Dados de fallback caso a API esteja indisponível."""
        return [
            {
                "title":     "NASA Artemis III: Preparativos Finais para o Retorno à Lua",
                "summary":   "A NASA confirma que os trajes lunares estão prontos para a missão Artemis III, que pousará os primeiros astronautas na Lua desde o Apollo 17.",
                "published": "2026-05-20",
                "source":    "NASA",
                "url":       "https://www.nasa.gov/artemis"
            },
            {
                "title":     "SpaceX Starship Completa Voo Orbital com Sucesso",
                "summary":   "O Starship da SpaceX concluiu seu voo orbital de demonstração, abrindo caminho para missões à Lua e a Marte dentro da próxima década.",
                "published": "2026-05-18",
                "source":    "SpaceX",
                "url":       "https://www.spacex.com/starship"
            },
            {
                "title":     "Telescópio James Webb Descobre Atmosfera em Exoplaneta",
                "summary":   "Cientistas detectaram moléculas de CO2 e vapor d'água na atmosfera de TRAPPIST-1e, o que aumenta as chances de habitabilidade do planeta.",
                "published": "2026-05-15",
                "source":    "ESA",
                "url":       "https://www.esa.int/jwst"
            },
            {
                "title":     "Rover Zhurong Identifica Sinais de Água Antiga em Marte",
                "summary":   "Dados do rover chinês Zhurong indicam presença de minerais hidratados na superfície de Utopia Planitia, sugerindo água líquida no passado marciano.",
                "published": "2026-05-12",
                "source":    "CNSA",
                "url":       "https://www.cnsa.gov.cn"
            },
            {
                "title":     "ISS Recebe Novo Módulo de Pesquisa Científica",
                "summary":   "A Estação Espacial Internacional incorporou o novo módulo AXIOM-3, ampliando a capacidade de experimentos científicos em microgravidade.",
                "published": "2026-05-10",
                "source":    "NASA/ESA",
                "url":       "https://www.nasa.gov/iss"
            },
        ]

    def scrape_wikipedia_missions(self) -> list[dict]:
        """
        Scraping da Wikipedia com BeautifulSoup4.
        Extrai lista de missões espaciais ativas.
        Tópico coberto: BS4 + seletores CSS
        """
        log.info("[SCRAPER] Scraping Wikipedia — missões espaciais ativas")
        missions_fallback = [
            {"name": "Artemis III",      "agency": "NASA",    "target": "Lua",           "status": "Em preparação", "launch_year": "2026"},
            {"name": "Mars Sample Return","agency": "NASA/ESA","target": "Marte",         "status": "Em desenvolvimento","launch_year": "2027"},
            {"name": "Europa Clipper",   "agency": "NASA",    "target": "Europa (Júpiter)","status": "Em trânsito",  "launch_year": "2024"},
            {"name": "JUICE",            "agency": "ESA",     "target": "Ganimedes",      "status": "Em trânsito",  "launch_year": "2023"},
            {"name": "Lunar Gateway",    "agency": "NASA/ESA","target": "Órbita Lunar",   "status": "Em construção","launch_year": "2025"},
            {"name": "Dragonfly",        "agency": "NASA",    "target": "Titã (Saturno)", "status": "Em desenvolvimento","launch_year": "2028"},
            {"name": "Chang'e 7",        "agency": "CNSA",    "target": "Lua (Polo Sul)", "status": "Em preparação","launch_year": "2026"},
            {"name": "Starship HLS",     "agency": "SpaceX",  "target": "Lua",           "status": "Em testes",    "launch_year": "2026"},
        ]

        try:
            url = "https://en.wikipedia.org/wiki/List_of_active_Solar_System_missions"
            resp = self.session.get(url, timeout=12)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")

            missions = []
            tables = soup.select("table.wikitable")
            if tables:
                rows = tables[0].select("tr")[1:9]  # Primeiras 8 missões
                for row in rows:
                    cols = row.select("td")
                    if len(cols) >= 3:
                        missions.append({
                            "name":        cols[0].get_text(strip=True)[:40],
                            "agency":      cols[1].get_text(strip=True)[:20] if len(cols) > 1 else "N/A",
                            "target":      cols[2].get_text(strip=True)[:30] if len(cols) > 2 else "N/A",
                            "status":      "Ativa",
                            "launch_year": cols[3].get_text(strip=True)[:4] if len(cols) > 3 else "N/A",
                        })
                if missions:
                    log.info(f"[SCRAPER] {len(missions)} missões coletadas da Wikipedia")
                    return missions

        except Exception as e:
            log.warning(f"[SCRAPER] Falha no scraping Wikipedia: {e}")

        log.info("[SCRAPER] Usando dados de missões de fallback")
        return missions_fallback


# ══════════════════════════════════════════════════════════════════
# MÓDULO 3 — IA: Análise inteligente com Claude API
# ══════════════════════════════════════════════════════════════════
class AIAnalyzer:
    """
    Usa o Gemini (Google AI) para análise inteligente dos dados coletados.
    Tópico coberto: IA / NLP / Gemini API integrado ao fluxo RPA
    API GRATUITA — obter chave em: aistudio.google.com
    """

    def __init__(self):
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise ValueError(
                "\n\n❌ CHAVE DO GEMINI NÃO ENCONTRADA!\n"
                "   Execute antes de rodar o robô:\n"
                "   Windows CMD: set GEMINI_API_KEY=sua_chave_aqui\n"
                "   Pegue sua chave GRATUITA em: aistudio.google.com\n"
            )
        genai_client = google_genai.Client(api_key=api_key)
        self.model_name = GEMINI_MODEL
        self.client = genai_client

    def analyze_space_data(self, context: dict) -> dict:
        """
        Envia dados coletados para o Gemini e recebe análise estruturada.
        Retorna JSON com insights, alertas e recomendações.
        """
        log.info("[IA] Enviando dados para análise com Google Gemini AI")

        prompt = f"""Você é um sistema de IA especializado em análise de missões espaciais para um robô RPA.

Analise os seguintes dados coletados em tempo real e retorne APENAS um JSON válido (sem markdown, sem explicações fora do JSON) com esta estrutura exata:

{{
  "resumo_executivo": "string com 3-4 frases resumindo o cenário espacial atual",
  "nivel_alerta": "VERDE|AMARELO|VERMELHO",
  "motivo_alerta": "string explicando o nível de alerta",
  "insights": ["insight 1", "insight 2", "insight 3"],
  "asteroides_perigosos": ["nome1", "nome2"],
  "recomendacoes": ["recomendação 1", "recomendação 2", "recomendação 3"],
  "tendencias": "string descrevendo tendências observadas nos dados",
  "score_atividade_espacial": 85
}}

DADOS COLETADOS:
- Astronautas no espaço: {context.get('num_astronautas', 0)} pessoas
- Posição ISS: lat={context.get('iss_lat', 'N/A')}, lon={context.get('iss_lon', 'N/A')}
- Objetos próximos à Terra (NEO): {context.get('neo_count', 0)} detectados
- Potencialmente perigosos: {context.get('hazardous_neos', [])}
- Notícias recentes: {context.get('news_titles', [])}
- Missões ativas: {context.get('mission_names', [])}
"""

        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt
            )
            raw = response.text.strip()
            # Remove possíveis blocos markdown que o modelo possa incluir
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            analysis = json.loads(raw)
            log.info(f"[IA] Análise concluída — Alerta: {analysis.get('nivel_alerta', 'N/A')}")
            return analysis

        except json.JSONDecodeError as e:
            log.error(f"[IA] Erro ao parsear JSON da resposta: {e}")
            return self._fallback_analysis(context)
        except Exception as e:
            log.error(f"[IA] Erro na chamada à API Gemini: {e}")
            return self._fallback_analysis(context)

    def _fallback_analysis(self, context: dict) -> dict:
        """Análise de fallback caso a API Claude falhe."""
        hazardous = context.get("hazardous_neos", [])
        return {
            "resumo_executivo": (
                f"Monitoramento orbital ativo com {context.get('num_astronautas', 7)} astronautas "
                f"em missão. A ISS continua sua operação nominal. "
                f"{context.get('neo_count', 0)} objetos próximos à Terra foram detectados, "
                f"sendo {len(hazardous)} classificados como potencialmente perigosos."
            ),
            "nivel_alerta": "AMARELO" if hazardous else "VERDE",
            "motivo_alerta": "Asteroide potencialmente perigoso detectado" if hazardous else "Operações normais",
            "insights": [
                "Tripulação da ISS continua experimentos em microgravidade",
                "Programa Artemis avança para retorno à Lua",
                "Múltiplas agências espaciais colaborando em missões ativas"
            ],
            "asteroides_perigosos": hazardous,
            "recomendacoes": [
                "Manter monitoramento contínuo de NEOs potencialmente perigosos",
                "Verificar janelas de lançamento para próximas missões",
                "Atualizar banco de dados de telemetria da ISS"
            ],
            "tendencias": "Aumento da atividade espacial comercial e colaborações internacionais",
            "score_atividade_espacial": 82
        }


# ══════════════════════════════════════════════════════════════════
# MÓDULO 4 — PLANILHAS: Exportação estruturada para Excel
# ══════════════════════════════════════════════════════════════════
class ExcelReporter:
    """
    Gera relatórios Excel formatados com todos os dados processados.
    Tópico coberto: openpyxl + formatação avançada de planilhas
    """

    # Paleta de cores do projeto
    COLOR_DARK   = "1B2A4A"   # Azul escuro espacial
    COLOR_ACCENT = "E84855"   # Vermelho alerta
    COLOR_MID    = "3D6B9E"   # Azul médio
    COLOR_LIGHT  = "D6E4F0"   # Azul claro
    COLOR_GREEN  = "27AE60"   # Verde status
    COLOR_YELLOW = "F39C12"   # Amarelo alerta
    COLOR_WHITE  = "FFFFFF"
    COLOR_GRAY   = "F5F5F5"

    def __init__(self):
        self.wb = openpyxl.Workbook()

    def _header_fill(self, color: str) -> PatternFill:
        return PatternFill("solid", fgColor=color)

    def _font(self, bold=False, color="000000", size=11, italic=False) -> Font:
        return Font(bold=bold, color=color, size=size, italic=italic,
                    name="Calibri")

    def _center(self) -> Alignment:
        return Alignment(horizontal="center", vertical="center", wrap_text=True)

    def _border(self) -> Border:
        s = Side(style="thin", color="CCCCCC")
        return Border(left=s, right=s, top=s, bottom=s)

    def _write_header_row(self, ws, row: int, cols: list[str], fill_color: str):
        for i, col in enumerate(cols, 1):
            cell = ws.cell(row=row, column=i, value=col)
            cell.fill    = self._header_fill(fill_color)
            cell.font    = self._font(bold=True, color=self.COLOR_WHITE, size=10)
            cell.alignment = self._center()
            cell.border  = self._border()

    def _write_cell(self, ws, row: int, col: int, value, fill_color: str = None,
                    bold=False, center=False):
        cell = ws.cell(row=row, column=col, value=value)
        if fill_color:
            cell.fill = self._header_fill(fill_color)
        cell.font      = self._font(bold=bold, size=10)
        cell.alignment = self._center() if center else Alignment(vertical="center", wrap_text=True)
        cell.border    = self._border()
        return cell

    # ── Aba 1: Dashboard ──────────────────────────────────────────
    def add_dashboard(self, ai_analysis: dict, num_astronautas: int,
                       iss_pos: dict, neo_count: int):
        ws = self.wb.active
        ws.title = "📊 Dashboard"
        ws.sheet_view.showGridLines = False
        ws.column_dimensions["A"].width = 30
        ws.column_dimensions["B"].width = 45
        ws.column_dimensions["C"].width = 20

        # Título principal
        ws.merge_cells("A1:C1")
        title = ws["A1"]
        title.value     = "🚀 ORBITAL SENTINEL — Dashboard de Missões Espaciais"
        title.fill      = self._header_fill(self.COLOR_DARK)
        title.font      = self._font(bold=True, color=self.COLOR_WHITE, size=16)
        title.alignment = self._center()
        ws.row_dimensions[1].height = 40

        # Timestamp
        ws.merge_cells("A2:C2")
        ts = ws["A2"]
        ts.value     = f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')} | Sistema: Orbital Sentinel v1.0"
        ts.fill      = self._header_fill(self.COLOR_MID)
        ts.font      = self._font(color=self.COLOR_WHITE, size=10, italic=True)
        ts.alignment = self._center()

        # KPIs
        row = 4
        ws.merge_cells(f"A{row}:C{row}")
        kpi_title = ws[f"A{row}"]
        kpi_title.value     = "INDICADORES EM TEMPO REAL"
        kpi_title.fill      = self._header_fill(self.COLOR_MID)
        kpi_title.font      = self._font(bold=True, color=self.COLOR_WHITE, size=12)
        kpi_title.alignment = self._center()

        kpis = [
            ("👨‍🚀 Astronautas no Espaço",   str(num_astronautas),    self.COLOR_LIGHT),
            ("🛸 Posição ISS (Latitude)",    iss_pos.get("latitude",  "N/A"), self.COLOR_GRAY),
            ("🛸 Posição ISS (Longitude)",   iss_pos.get("longitude", "N/A"), self.COLOR_LIGHT),
            ("☄️ Objetos Próximos à Terra",  str(neo_count),          self.COLOR_GRAY),
            ("⚠️ Nível de Alerta IA",        ai_analysis.get("nivel_alerta", "N/A"),
                "FFD700" if ai_analysis.get("nivel_alerta") == "AMARELO" else
                "90EE90" if ai_analysis.get("nivel_alerta") == "VERDE" else "FFB6B6"),
            ("📈 Score de Atividade",
                f"{ai_analysis.get('score_atividade_espacial', 0)}/100", self.COLOR_LIGHT),
        ]

        for i, (label, value, color) in enumerate(kpis):
            r = row + 1 + i
            ws.row_dimensions[r].height = 28
            self._write_cell(ws, r, 1, label,  self.COLOR_DARK, bold=True, center=False)
            ws["A" + str(r)].font = self._font(bold=True, color=self.COLOR_WHITE, size=10)
            self._write_cell(ws, r, 2, value,  color, bold=True, center=True)
            self._write_cell(ws, r, 3, "✔ Coletado", "90EE90", center=True)

        # Resumo IA
        row2 = row + len(kpis) + 2
        ws.merge_cells(f"A{row2}:C{row2}")
        s_title = ws[f"A{row2}"]
        s_title.value     = "ANÁLISE DE INTELIGÊNCIA ARTIFICIAL"
        s_title.fill      = self._header_fill(self.COLOR_ACCENT)
        s_title.font      = self._font(bold=True, color=self.COLOR_WHITE, size=12)
        s_title.alignment = self._center()
        ws.row_dimensions[row2].height = 28

        ws.merge_cells(f"A{row2+1}:C{row2+1}")
        resumo = ws[f"A{row2+1}"]
        resumo.value     = ai_analysis.get("resumo_executivo", "N/A")
        resumo.alignment = Alignment(wrap_text=True, vertical="top")
        resumo.border    = self._border()
        resumo.fill      = self._header_fill(self.COLOR_GRAY)
        ws.row_dimensions[row2+1].height = 70

        # Recomendações IA
        row3 = row2 + 3
        ws.merge_cells(f"A{row3}:C{row3}")
        r_title = ws[f"A{row3}"]
        r_title.value     = "RECOMENDAÇÕES DO SISTEMA DE IA"
        r_title.fill      = self._header_fill(self.COLOR_MID)
        r_title.font      = self._font(bold=True, color=self.COLOR_WHITE, size=12)
        r_title.alignment = self._center()

        for i, rec in enumerate(ai_analysis.get("recomendacoes", []), 1):
            r = row3 + i
            ws.merge_cells(f"A{r}:C{r}")
            cell = ws[f"A{r}"]
            cell.value     = f"  {i}. {rec}"
            cell.alignment = Alignment(wrap_text=True, vertical="center")
            cell.border    = self._border()
            cell.fill      = self._header_fill(self.COLOR_LIGHT if i % 2 else self.COLOR_GRAY)
            ws.row_dimensions[r].height = 25

    # ── Aba 2: Astronautas ────────────────────────────────────────
    def add_astronauts_sheet(self, astronaut_data: dict):
        ws = self.wb.create_sheet("👨‍🚀 Astronautas")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:D1")
        t = ws["A1"]
        t.value     = f"ASTRONAUTAS NO ESPAÇO — {datetime.now().strftime('%d/%m/%Y')}"
        t.fill      = self._header_fill(self.COLOR_DARK)
        t.font      = self._font(bold=True, color=self.COLOR_WHITE, size=14)
        t.alignment = self._center()
        ws.row_dimensions[1].height = 35

        cols = ["#", "Nome do Astronauta", "Nave / Estação", "Status"]
        widths = [6, 35, 25, 20]
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            ws.column_dimensions[chr(64+i)].width = w
        self._write_header_row(ws, 2, cols, self.COLOR_MID)

        people = astronaut_data.get("people", [])
        for i, person in enumerate(people, 1):
            fill = self.COLOR_LIGHT if i % 2 == 0 else self.COLOR_GRAY
            r = i + 2
            self._write_cell(ws, r, 1, i,                     fill, center=True)
            self._write_cell(ws, r, 2, person.get("name",""),  fill)
            self._write_cell(ws, r, 3, person.get("craft",""), fill, center=True)
            self._write_cell(ws, r, 4, "✅ Em Missão",         "90EE90", center=True)
            ws.row_dimensions[r].height = 22

        # Total
        r_total = len(people) + 3
        ws.merge_cells(f"A{r_total}:C{r_total}")
        total = ws[f"A{r_total}"]
        total.value     = f"Total de Astronautas em Missão: {len(people)}"
        total.fill      = self._header_fill(self.COLOR_DARK)
        total.font      = self._font(bold=True, color=self.COLOR_WHITE, size=11)
        total.alignment = self._center()

    # ── Aba 3: Missões Espaciais ──────────────────────────────────
    def add_missions_sheet(self, missions: list[dict]):
        ws = self.wb.create_sheet("🚀 Missões")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:E1")
        t = ws["A1"]
        t.value     = "MISSÕES ESPACIAIS ATIVAS — DADOS COLETADOS VIA WEB SCRAPING"
        t.fill      = self._header_fill(self.COLOR_DARK)
        t.font      = self._font(bold=True, color=self.COLOR_WHITE, size=14)
        t.alignment = self._center()
        ws.row_dimensions[1].height = 35

        cols   = ["Missão", "Agência", "Destino", "Status", "Ano de Lançamento"]
        widths = [30, 20, 25, 20, 18]
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            ws.column_dimensions[chr(64+i)].width = w
        self._write_header_row(ws, 2, cols, self.COLOR_ACCENT)

        for i, m in enumerate(missions, 1):
            fill = self.COLOR_LIGHT if i % 2 == 0 else self.COLOR_GRAY
            r = i + 2
            self._write_cell(ws, r, 1, m.get("name",""),        fill, bold=True)
            self._write_cell(ws, r, 2, m.get("agency",""),      fill, center=True)
            self._write_cell(ws, r, 3, m.get("target",""),      fill)
            self._write_cell(ws, r, 4, m.get("status",""),      fill, center=True)
            self._write_cell(ws, r, 5, m.get("launch_year",""), fill, center=True)
            ws.row_dimensions[r].height = 22

    # ── Aba 4: Notícias ───────────────────────────────────────────
    def add_news_sheet(self, news: list[dict]):
        ws = self.wb.create_sheet("📰 Notícias")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:E1")
        t = ws["A1"]
        t.value     = "NOTÍCIAS ESPACIAIS — COLETADAS VIA WEB SCRAPING"
        t.fill      = self._header_fill(self.COLOR_DARK)
        t.font      = self._font(bold=True, color=self.COLOR_WHITE, size=14)
        t.alignment = self._center()
        ws.row_dimensions[1].height = 35

        cols   = ["Data", "Fonte", "Título", "Resumo", "URL"]
        widths = [14, 15, 40, 55, 40]
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            ws.column_dimensions[chr(64+i)].width = w
        self._write_header_row(ws, 2, cols, self.COLOR_MID)

        for i, n in enumerate(news, 1):
            fill = self.COLOR_LIGHT if i % 2 == 0 else self.COLOR_GRAY
            r = i + 2
            self._write_cell(ws, r, 1, n.get("published",""), fill, center=True)
            self._write_cell(ws, r, 2, n.get("source",""),    fill, center=True)
            self._write_cell(ws, r, 3, n.get("title",""),     fill, bold=True)
            self._write_cell(ws, r, 4, n.get("summary",""),   fill)
            self._write_cell(ws, r, 5, n.get("url",""),       fill)
            ws.row_dimensions[r].height = 45

    # ── Aba 5: Análise IA ─────────────────────────────────────────
    def add_ai_analysis_sheet(self, analysis: dict):
        ws = self.wb.create_sheet("🤖 Análise IA")
        ws.sheet_view.showGridLines = False
        ws.column_dimensions["A"].width = 30
        ws.column_dimensions["B"].width = 65

        ws.merge_cells("A1:B1")
        t = ws["A1"]
        t.value     = "ANÁLISE DE INTELIGÊNCIA ARTIFICIAL — CLAUDE (ANTHROPIC)"
        t.fill      = self._header_fill(self.COLOR_DARK)
        t.font      = self._font(bold=True, color=self.COLOR_WHITE, size=14)
        t.alignment = self._center()
        ws.row_dimensions[1].height = 35

        fields = [
            ("Resumo Executivo",        analysis.get("resumo_executivo","")),
            ("Nível de Alerta",         analysis.get("nivel_alerta","")),
            ("Motivo do Alerta",        analysis.get("motivo_alerta","")),
            ("Tendências Observadas",   analysis.get("tendencias","")),
            ("Score de Atividade",      f"{analysis.get('score_atividade_espacial',0)}/100"),
            ("Asteroides Perigosos",    ", ".join(analysis.get("asteroides_perigosos",[])  or ["Nenhum detectado"])),
        ]

        for i, (label, value) in enumerate(fields, 2):
            ws.row_dimensions[i].height = 45
            self._write_cell(ws, i, 1, label, self.COLOR_MID, bold=True, center=True)
            ws["A"+str(i)].font = self._font(bold=True, color=self.COLOR_WHITE, size=10)
            self._write_cell(ws, i, 2, value, self.COLOR_GRAY if i%2 else self.COLOR_LIGHT)

        # Insights
        row_i = len(fields) + 3
        ws.merge_cells(f"A{row_i}:B{row_i}")
        ins_title = ws[f"A{row_i}"]
        ins_title.value     = "INSIGHTS GERADOS PELA IA"
        ins_title.fill      = self._header_fill(self.COLOR_ACCENT)
        ins_title.font      = self._font(bold=True, color=self.COLOR_WHITE, size=12)
        ins_title.alignment = self._center()

        for j, insight in enumerate(analysis.get("insights",[]), 1):
            r = row_i + j
            ws.row_dimensions[r].height = 35
            self._write_cell(ws, r, 1, f"Insight {j}", self.COLOR_MID, bold=True, center=True)
            ws["A"+str(r)].font = self._font(bold=True, color=self.COLOR_WHITE, size=10)
            self._write_cell(ws, r, 2, insight, self.COLOR_LIGHT if j%2 else self.COLOR_GRAY)

    # ── Aba 6: NEO — Objetos Próximos à Terra ─────────────────────
    def add_neo_sheet(self, neo_data: dict):
        ws = self.wb.create_sheet("☄️ Asteroides NEO")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:F1")
        t = ws["A1"]
        t.value     = "NEAR-EARTH OBJECTS (NEO) — NASA NeoWs API"
        t.fill      = self._header_fill(self.COLOR_DARK)
        t.font      = self._font(bold=True, color=self.COLOR_WHITE, size=14)
        t.alignment = self._center()
        ws.row_dimensions[1].height = 35

        cols   = ["Nome", "Perigoso?", "Diâm. Máx. (km)", "Distância (km)", "Vel. (km/s)", "Status"]
        widths = [20, 15, 18, 18, 15, 18]
        for i, (c, w) in enumerate(zip(cols, widths), 1):
            ws.column_dimensions[chr(64+i)].width = w
        self._write_header_row(ws, 2, cols, self.COLOR_ACCENT)

        all_neos = []
        for neos in neo_data.get("near_earth_objects", {}).values():
            all_neos.extend(neos)

        for i, neo in enumerate(all_neos[:20], 1):
            hazardous = neo.get("is_potentially_hazardous_asteroid", False)
            fill = "FFB6B6" if hazardous else (self.COLOR_LIGHT if i%2==0 else self.COLOR_GRAY)
            r = i + 2

            diam = neo.get("estimated_diameter",{}).get("kilometers",{}).get("estimated_diameter_max",0)
            approach = neo.get("close_approach_data", [{}])[0]
            dist = approach.get("miss_distance",{}).get("kilometers","N/A")
            vel  = approach.get("relative_velocity",{}).get("kilometers_per_second","N/A")

            self._write_cell(ws, r, 1, neo.get("name",""),          fill, bold=hazardous)
            self._write_cell(ws, r, 2, "⚠️ SIM" if hazardous else "✅ NÃO",
                             "FFB6B6" if hazardous else "90EE90", center=True)
            self._write_cell(ws, r, 3, round(float(diam),4) if diam else "N/A", fill, center=True)
            self._write_cell(ws, r, 4, f"{float(dist):,.0f}" if dist != "N/A" else "N/A", fill, center=True)
            self._write_cell(ws, r, 5, f"{float(vel):.2f}" if vel != "N/A" else "N/A",  fill, center=True)
            self._write_cell(ws, r, 6, "ALERTA" if hazardous else "Monitorando",
                             "FFB6B6" if hazardous else fill, center=True)
            ws.row_dimensions[r].height = 22

    def save(self, path: Path) -> Path:
        self.wb.save(path)
        log.info(f"[EXCEL] Relatório salvo em: {path}")
        return path


# ══════════════════════════════════════════════════════════════════
# MÓDULO 5 — PIPELINE PRINCIPAL: Orquestra todo o fluxo RPA
# ══════════════════════════════════════════════════════════════════
class OrbitalSentinelPipeline:
    """
    Orquestra o fluxo completo de automação:
    Coleta → Scraping → Análise IA → Exportação → Relatório
    """

    def __init__(self):
        self.api_collector = SpaceAPICollector()
        self.scraper       = SpaceNewsScraper()
        self.ai_analyzer   = AIAnalyzer()
        self.timestamp     = datetime.now().strftime("%Y%m%d_%H%M%S")

    def run(self):
        log.info("=" * 65)
        log.info("  ORBITAL SENTINEL — INICIANDO PIPELINE RPA")
        log.info(f"  Execução: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        log.info("=" * 65)

        # ── ETAPA 1: Coleta via REST API ──────────────────────────
        log.info("[PIPELINE] ETAPA 1/5 — Coleta de dados via REST API")
        astronaut_data  = self.api_collector.get_people_in_space()
        iss_data        = self.api_collector.get_iss_position()
        apod_data       = self.api_collector.get_nasa_apod()
        neo_data        = self.api_collector.get_near_earth_objects()

        # ── ETAPA 2: Web Scraping ─────────────────────────────────
        log.info("[PIPELINE] ETAPA 2/5 — Web Scraping de missões e notícias")
        news_list       = self.scraper.scrape_spacenews_api()
        missions_list   = self.scraper.scrape_wikipedia_missions()

        # ── ETAPA 3: Persistência dos dados brutos (JSON) ─────────
        log.info("[PIPELINE] ETAPA 3/5 — Persistência dos dados brutos")
        raw_data = {
            "timestamp":    self.timestamp,
            "astronautas":  astronaut_data,
            "iss_position": iss_data,
            "apod":         apod_data,
            "neo":          neo_data,
            "news":         news_list,
            "missions":     missions_list,
        }
        raw_path = DATA_DIR / f"raw_data_{self.timestamp}.json"
        raw_path.write_text(json.dumps(raw_data, ensure_ascii=False, indent=2), encoding="utf-8")
        log.info(f"[PIPELINE] Dados brutos salvos em: {raw_path}")

        # ── ETAPA 4: Análise com IA ───────────────────────────────
        log.info("[PIPELINE] ETAPA 4/5 — Análise inteligente com Claude AI")
        iss_pos       = iss_data.get("iss_position", {})
        all_neos      = []
        for neos in neo_data.get("near_earth_objects", {}).values():
            all_neos.extend(neos)
        hazardous     = [n["name"] for n in all_neos if n.get("is_potentially_hazardous_asteroid")]

        ai_context = {
            "num_astronautas":   astronaut_data.get("number", 0),
            "iss_lat":           iss_pos.get("latitude","N/A"),
            "iss_lon":           iss_pos.get("longitude","N/A"),
            "neo_count":         neo_data.get("element_count", len(all_neos)),
            "hazardous_neos":    hazardous,
            "news_titles":       [n["title"] for n in news_list[:5]],
            "mission_names":     [m["name"] for m in missions_list[:6]],
        }
        ai_analysis = self.ai_analyzer.analyze_space_data(ai_context)

        # Salva análise IA em JSON
        ai_path = DATA_DIR / f"ai_analysis_{self.timestamp}.json"
        ai_path.write_text(json.dumps(ai_analysis, ensure_ascii=False, indent=2), encoding="utf-8")

        # ── ETAPA 5: Geração do relatório Excel ───────────────────
        log.info("[PIPELINE] ETAPA 5/5 — Geração do relatório Excel")
        reporter = ExcelReporter()
        reporter.add_dashboard(
            ai_analysis     = ai_analysis,
            num_astronautas = astronaut_data.get("number", 0),
            iss_pos         = iss_pos,
            neo_count       = neo_data.get("element_count", len(all_neos))
        )
        reporter.add_astronauts_sheet(astronaut_data)
        reporter.add_missions_sheet(missions_list)
        reporter.add_news_sheet(news_list)
        reporter.add_ai_analysis_sheet(ai_analysis)
        reporter.add_neo_sheet(neo_data)

        excel_path = OUTPUT_DIR / f"orbital_sentinel_{self.timestamp}.xlsx"
        reporter.save(excel_path)

        log.info("=" * 65)
        log.info("  PIPELINE CONCLUÍDO COM SUCESSO!")
        log.info(f"  Relatório Excel: {excel_path}")
        log.info(f"  Dados brutos:    {raw_path}")
        log.info(f"  Análise IA:      {ai_path}")
        log.info("=" * 65)

        return {
            "excel":    str(excel_path),
            "raw_data": str(raw_path),
            "ai":       str(ai_path),
            "analysis": ai_analysis,
        }


# ══════════════════════════════════════════════════════════════════
# MÓDULO 6 — AGENDAMENTO: Execução periódica automática
# ══════════════════════════════════════════════════════════════════
def run_scheduled():
    """Função chamada pelo agendador — executa o pipeline completo."""
    pipeline = OrbitalSentinelPipeline()
    pipeline.run()


def start_scheduler(interval_minutes: int = 60):
    """
    Configura e inicia o agendador de tarefas.
    Tópico coberto: schedule + execução periódica automática
    """
    log.info(f"[SCHEDULER] Agendamento configurado: a cada {interval_minutes} minuto(s)")
    schedule.every(interval_minutes).minutes.do(run_scheduled)

    # Executa imediatamente na primeira vez
    run_scheduled()

    log.info("[SCHEDULER] Aguardando próxima execução agendada... (Ctrl+C para parar)")
    while True:
        schedule.run_pending()
        time.sleep(30)


# ══════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--schedule":
        # Modo agendado: python main.py --schedule
        interval = int(sys.argv[2]) if len(sys.argv) > 2 else 60
        start_scheduler(interval)
    else:
        # Modo único: python main.py
        pipeline = OrbitalSentinelPipeline()
        result   = pipeline.run()
        print(f"\n✅ Concluído! Relatório em: {result['excel']}")
