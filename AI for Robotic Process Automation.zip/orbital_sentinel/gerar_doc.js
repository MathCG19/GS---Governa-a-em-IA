const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  PageNumber, Footer, Header, LevelFormat, PageBreak
} = require("docx");
const fs = require("fs");

const DARK   = "1B2A4A";
const ACCENT = "E84855";
const MID    = "3D6B9E";
const LIGHT  = "D6E4F0";
const WHITE  = "FFFFFF";
const GRAY   = "F5F7FA";

const border = (c="CCCCCC") => ({ style: BorderStyle.SINGLE, size: 1, color: c });
const borders = (c) => ({ top: border(c), bottom: border(c), left: border(c), right: border(c) });

function cell(text, opts={}) {
  const { fill=null, bold=false, color="000000", center=false, size=20, colspan=1 } = opts;
  return new TableCell({
    columnSpan: colspan,
    borders: borders(fill || "CCCCCC"),
    width: { size: opts.width || 2340, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    shading: fill ? { fill, type: ShadingType.CLEAR } : undefined,
    children: [new Paragraph({
      alignment: center ? AlignmentType.CENTER : AlignmentType.LEFT,
      children: [new TextRun({ text: String(text), bold, color, size, font: "Calibri" })]
    })]
  });
}

function hCell(text, fill=MID) {
  return cell(text, { fill, bold: true, color: WHITE, center: true, size: 20 });
}

function heading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, bold: true, color: DARK, size: 36, font: "Calibri" })]
  });
}

function heading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, bold: true, color: MID, size: 28, font: "Calibri" })]
  });
}

function heading3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 160, after: 80 },
    children: [new TextRun({ text, bold: true, color: ACCENT, size: 24, font: "Calibri" })]
  });
}

function body(text, opts={}) {
  return new Paragraph({
    spacing: { before: 80, after: 80, line: 320 },
    children: [new TextRun({ text, size: 22, font: "Calibri", ...opts })]
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 60, after: 60, line: 300 },
    children: [new TextRun({ text, size: 22, font: "Calibri" })]
  });
}

function codeBlock(text) {
  return new Paragraph({
    spacing: { before: 80, after: 80 },
    shading: { fill: "1E1E1E", type: ShadingType.CLEAR },
    border: { top: border("444444"), bottom: border("444444"), left: { style: BorderStyle.THICK, size: 8, color: ACCENT }, right: border("444444") },
    children: [new TextRun({ text, font: "Courier New", size: 18, color: "98C379" })]
  });
}

function spacer(n=1) {
  return Array.from({length:n}, () => new Paragraph({ spacing: { before: 60, after: 60 }, children: [new TextRun("")] }));
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

// ─── TABELA: Matriz de Avaliação ────────────────────────────────
function avaliacaoTable() {
  const W = 9360;
  const rows_data = [
    ["Domínio Técnico e Integração de Conceitos", "40%",
     "✅ Integra 4 tópicos: REST API, Web Scraping (BS4), IA (Claude API), openpyxl + schedule. Pipeline funcional de ponta a ponta.", LIGHT],
    ["Arquitetura de Fluxo e Engenharia de Software", "25%",
     "✅ 6 módulos independentes, tratamento de exceções em todas as etapas, fallback de dados, logging estruturado com arquivo e console.", GRAY],
    ["Inteligência de Dados e Recursos de IA", "20%",
     "✅ LLM (Claude) integrado ao fluxo para análise semântica dos dados coletados, gerando score, alertas, insights e recomendações.", LIGHT],
    ["Entrega de Artefatos e Outputs Técnicos", "15%",
     "✅ Relatório Excel com 6 abas formatadas, JSON de dados brutos, JSON de análise IA e arquivo de log rastreável.", GRAY],
  ];
  return new Table({
    width: { size: W, type: WidthType.DXA },
    columnWidths: [3000, 800, 4360, 1200],
    rows: [
      new TableRow({ children: [
        hCell("Critério Técnico", DARK), hCell("Peso", DARK),
        hCell("Como o Projeto Atende", DARK), hCell("Status", DARK)
      ]}),
      ...rows_data.map(([crit, peso, det, fill]) =>
        new TableRow({ children: [
          cell(crit, { fill, bold: true, width: 3000 }),
          cell(peso, { fill: ACCENT, bold: true, color: WHITE, center: true, width: 800 }),
          cell(det,  { fill, width: 4360 }),
          cell("100%", { fill: "27AE60", bold: true, color: WHITE, center: true, width: 1200 }),
        ]})
      )
    ]
  });
}

// ─── TABELA: Tecnologias usadas ──────────────────────────────────
function techTable() {
  const rows_data = [
    ["requests",      "REST API",       "Coleta dados de missões, ISS e NEO via NASA + Open Notify APIs"],
    ["beautifulsoup4","Web Scraping",   "Extrai missões ativas da Wikipedia e notícias da Spaceflight News API"],
    ["anthropic",     "IA / NLP",       "Análise semântica dos dados: score, alerta, insights e recomendações"],
    ["openpyxl",      "Planilhas",      "Geração de relatório Excel com 6 abas, formatação e estilos profissionais"],
    ["schedule",      "Agendamento",    "Execução automática periódica do pipeline sem intervenção humana"],
    ["json / pathlib","Arquivos",       "Persistência de dados brutos e análise IA em formato JSON estruturado"],
    ["logging",       "Monitoramento",  "Registro completo de cada etapa em arquivo .log e console com timestamp"],
  ];
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1600, 6160],
    rows: [
      new TableRow({ children: [hCell("Biblioteca"), hCell("Tópico FIAP"), hCell("Papel no Sistema")] }),
      ...rows_data.map(([lib, topic, role], i) =>
        new TableRow({ children: [
          cell(lib,   { fill: i%2===0 ? LIGHT : GRAY, bold: true, width: 1600 }),
          cell(topic, { fill: ACCENT, bold: true, color: WHITE, center: true, width: 1600 }),
          cell(role,  { fill: i%2===0 ? LIGHT : GRAY, width: 6160 }),
        ]})
      )
    ]
  });
}

// ─── TABELA: Saídas geradas ──────────────────────────────────────
function outputsTable() {
  const rows_data = [
    ["orbital_sentinel_TIMESTAMP.xlsx", "Excel (6 abas)",  "Dashboard, astronautas, missões, notícias, análise IA, asteroides"],
    ["raw_data_TIMESTAMP.json",         "JSON",            "Todos os dados brutos coletados via API e scraping"],
    ["ai_analysis_TIMESTAMP.json",      "JSON",            "Resposta estruturada do Claude com score, alertas e insights"],
    ["orbital_TIMESTAMP.log",           "Log",             "Registro auditável de toda a execução com timestamps e status"],
  ];
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3000, 1500, 4860],
    rows: [
      new TableRow({ children: [hCell("Arquivo"), hCell("Formato"), hCell("Conteúdo")] }),
      ...rows_data.map(([file, fmt, desc], i) =>
        new TableRow({ children: [
          cell(file, { fill: i%2===0 ? LIGHT : GRAY, bold: true, width: 3000 }),
          cell(fmt,  { fill: MID, bold: true, color: WHITE, center: true, width: 1500 }),
          cell(desc, { fill: i%2===0 ? LIGHT : GRAY, width: 4860 }),
        ]})
      )
    ]
  });
}

// ─── DOCUMENTO ───────────────────────────────────────────────────
const doc = new Document({
  numbering: {
    config: [{
      reference: "bullets",
      levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
    }]
  },
  styles: {
    default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: "Calibri", color: DARK },
        paragraph: { spacing: { before: 320, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Calibri", color: MID },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Calibri", color: ACCENT },
        paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1440, right: 1080, bottom: 1440, left: 1080 }
      }
    },
    children: [

      // ═══════════════════════════════════════
      // CAPA
      // ═══════════════════════════════════════
      new Paragraph({
        spacing: { before: 1440, after: 240 },
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "🚀", size: 72, font: "Segoe UI Emoji" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 160 },
        children: [new TextRun({ text: "ORBITAL SENTINEL", bold: true, size: 56, color: DARK, font: "Calibri" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 80 },
        children: [new TextRun({ text: "Sistema Automatizado de Monitoramento de Missões Espaciais", size: 28, color: MID, font: "Calibri", italics: true })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 80, after: 480 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 1 } },
        children: [new TextRun({ text: "", size: 22 })]
      }),

      new Table({
        width: { size: 6000, type: WidthType.DXA },
        columnWidths: [2200, 3800],
        rows: [
          new TableRow({ children: [
            cell("Instituição",     { fill: DARK, bold: true, color: WHITE, center: true, width: 2200 }),
            cell("FIAP",           { fill: LIGHT, width: 3800 }),
          ]}),
          new TableRow({ children: [
            cell("Disciplina",     { fill: DARK, bold: true, color: WHITE, center: true, width: 2200 }),
            cell("AI for RPA",     { fill: GRAY, width: 3800 }),
          ]}),
          new TableRow({ children: [
            cell("Avaliação",      { fill: DARK, bold: true, color: WHITE, center: true, width: 2200 }),
            cell("Global Solution 2026", { fill: LIGHT, width: 3800 }),
          ]}),
          new TableRow({ children: [
            cell("Semestre",       { fill: DARK, bold: true, color: WHITE, center: true, width: 2200 }),
            cell("1º Semestre — Graduação em Tecnologia", { fill: GRAY, width: 3800 }),
          ]}),
          new TableRow({ children: [
            cell("Data",           { fill: DARK, bold: true, color: WHITE, center: true, width: 2200 }),
            cell("Maio de 2026",   { fill: LIGHT, width: 3800 }),
          ]}),
        ]
      }),

      ...spacer(2),
      pageBreak(),

      // ═══════════════════════════════════════
      // 1. CONTEXTUALIZAÇÃO
      // ═══════════════════════════════════════
      heading1("1. Contextualização e Problema"),
      body("A Nova Exploração Espacial gera diariamente volumes massivos de dados não estruturados: telemetria de missões, logs de sistemas de bordo, alertas de objetos próximos à Terra (NEO), relatórios de experimentos e posicionamento de estações orbitais."),
      ...spacer(1),
      body("O desafio central é transformar essa avalanche de dados brutos em inteligência acionável de forma automatizada, sem intervenção humana constante — exatamente o papel da automação RPA integrada com Inteligência Artificial."),
      ...spacer(1),
      body("O Orbital Sentinel resolve esse problema implementando um pipeline RPA completo que coleta, processa, analisa com IA e exporta automaticamente todos os dados relevantes de exploração espacial em um ciclo totalmente automatizado."),
      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 2. SOLUÇÃO
      // ═══════════════════════════════════════
      heading1("2. Solução Proposta — Orbital Sentinel"),
      body("O Orbital Sentinel é um robô RPA desenvolvido em Python que monitora continuamente o cenário de exploração espacial global. O sistema opera em 5 etapas sequenciais, cada uma correspondendo a um módulo técnico independente:"),
      ...spacer(1),

      heading2("2.1 Arquitetura do Pipeline"),
      body("O fluxo de automação é composto por 6 módulos Python, cada um responsável por uma camada específica do processamento:"),
      ...spacer(1),

      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [600, 2500, 1800, 4460],
        rows: [
          new TableRow({ children: [hCell("Etapa"), hCell("Módulo"), hCell("Tópico FIAP"), hCell("Descrição")] }),
          ...[
            ["1", "SpaceAPICollector",     "REST API",      "Consome NASA APIs (APOD, NeoWs) e Open Notify (ISS, astronautas) com tratamento de exceções e fallback automático"],
            ["2", "SpaceNewsScraper",      "BS4 + Scraping","Coleta notícias via Spaceflight News API e faz scraping da Wikipedia extraindo missões ativas com seletores CSS"],
            ["3", "Persistência JSON",     "Arquivos",      "Salva todos os dados brutos em JSON estruturado com timestamp, garantindo rastreabilidade e auditoria"],
            ["4", "AIAnalyzer",            "IA / NLP",      "Envia contexto ao Claude (LLM) via API e recebe análise estruturada: score, nível de alerta, insights e recomendações"],
            ["5", "ExcelReporter",         "openpyxl",      "Gera relatório Excel com 6 abas temáticas formatadas profissionalmente com cores, bordas e estilos condicionais"],
            ["6", "OrbitalSentinelPipeline + schedule", "Agendamento", "Orquestra todas as etapas e permite execução automática periódica via schedule"],
          ].map(([et, mod, top, desc], i) =>
            new TableRow({ children: [
              cell(et,   { fill: ACCENT, bold: true, color: WHITE, center: true, width: 600 }),
              cell(mod,  { fill: i%2===0 ? LIGHT : GRAY, bold: true, width: 2500 }),
              cell(top,  { fill: MID, bold: true, color: WHITE, center: true, width: 1800 }),
              cell(desc, { fill: i%2===0 ? LIGHT : GRAY, width: 4460 }),
            ]})
          )
        ]
      }),

      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 3. TÓPICOS INTEGRADOS
      // ═══════════════════════════════════════
      heading1("3. Tópicos do Semestre Integrados"),
      body("O projeto combina obrigatoriamente ao menos dois grandes tópicos do semestre. O Orbital Sentinel integra quatro tópicos principais, superando o requisito mínimo:"),
      ...spacer(1),
      techTable(),
      ...spacer(1),

      heading2("3.1 Detalhamento Técnico dos Tópicos"),

      heading3("3.1.1 REST API (rpa_ia_api + rpa_ia_rest_api)"),
      body("O módulo SpaceAPICollector implementa um cliente HTTP robusto utilizando a biblioteca requests. Todas as requisições são encapsuladas no método _safe_get(), que trata individualmente cada tipo de exceção:"),
      ...spacer(1),
      codeBlock("def _safe_get(self, url, params=None, timeout=10):"),
      codeBlock("    try:"),
      codeBlock("        resp = self.session.get(url, params=params, timeout=timeout)"),
      codeBlock("        resp.raise_for_status()  # Lança HTTPError para 4xx/5xx"),
      codeBlock("        return resp.json()"),
      codeBlock("    except requests.exceptions.Timeout:"),
      codeBlock("        log.error(f'[API] Timeout: {url}')"),
      codeBlock("    except requests.exceptions.HTTPError as e:"),
      codeBlock("        log.error(f'[API] Erro HTTP {e.response.status_code}')"),
      codeBlock("    except requests.exceptions.ConnectionError:"),
      codeBlock("        log.error(f'[API] Falha de conexão')"),
      codeBlock("    return None  # Fallback ativado automaticamente"),
      ...spacer(1),
      body("APIs consumidas: Open Notify (astronautas em órbita, posição ISS), NASA APOD (Astronomy Picture of the Day), NASA NeoWs (Near Earth Objects — asteroides próximos à Terra) e Spaceflight News API (notícias em tempo real)."),
      ...spacer(1),

      heading3("3.1.2 Web Scraping — BS4 + XPath/CSS (rpa_ia_bs4)"),
      body("O módulo SpaceNewsScraper utiliza BeautifulSoup4 para fazer parsing de HTML e extrair dados estruturados. Os seletores CSS são usados para localizar tabelas e linhas específicas:"),
      ...spacer(1),
      codeBlock("soup = BeautifulSoup(resp.text, 'html.parser')"),
      codeBlock("tables = soup.select('table.wikitable')   # Seletor CSS"),
      codeBlock("rows   = tables[0].select('tr')[1:9]      # Primeiras 8 missões"),
      codeBlock("for row in rows:"),
      codeBlock("    cols = row.select('td')               # Células da linha"),
      codeBlock("    missions.append({"),
      codeBlock("        'name':        cols[0].get_text(strip=True),"),
      codeBlock("        'agency':      cols[1].get_text(strip=True),"),
      codeBlock("        'target':      cols[2].get_text(strip=True),"),
      codeBlock("    })"),
      ...spacer(1),

      heading3("3.1.3 IA / NLP — Claude API (rpa_ia_api)"),
      body("O módulo AIAnalyzer integra o modelo de linguagem Claude (Anthropic) ao pipeline RPA. O contexto coletado nas etapas anteriores é enviado ao LLM via API, que retorna uma análise estruturada em JSON com score de atividade espacial, nível de alerta, insights e recomendações operacionais."),
      ...spacer(1),
      codeBlock("response = self.client.messages.create("),
      codeBlock("    model='claude-sonnet-4-20250514',"),
      codeBlock("    max_tokens=1024,"),
      codeBlock("    messages=[{'role': 'user', 'content': prompt}]"),
      codeBlock(")"),
      codeBlock("analysis = json.loads(response.content[0].text)"),
      ...spacer(1),
      body("O prompt de IA foi projetado com engenharia de prompt estruturada, solicitando JSON com campos específicos: resumo_executivo, nivel_alerta (VERDE/AMARELO/VERMELHO), insights (lista), asteroides_perigosos, recomendacoes e score_atividade_espacial (0–100)."),
      ...spacer(1),

      heading3("3.1.4 Planilhas Excel — openpyxl (rpa_ia_arquivos_database)"),
      body("O módulo ExcelReporter gera um relatório Excel profissional com 6 abas temáticas. Cada aba aplica estilos programáticos: cores condicionais (verde = seguro, vermelho = perigo), bordas, alinhamentos e cabeçalhos formatados."),
      ...spacer(1),
      codeBlock("cell.fill      = PatternFill('solid', fgColor='1B2A4A')"),
      codeBlock("cell.font      = Font(bold=True, color='FFFFFF', size=12)"),
      codeBlock("cell.alignment = Alignment(horizontal='center', wrap_text=True)"),
      codeBlock("cell.border    = Border(left=Side(style='thin'), ...)"),
      ...spacer(1),

      heading3("3.1.5 Agendamento — schedule (execuca_scripts_agendamento)"),
      body("O sistema pode operar em modo agendado, executando o pipeline completo automaticamente em intervalos configuráveis, sem intervenção humana:"),
      ...spacer(1),
      codeBlock("schedule.every(60).minutes.do(run_scheduled)"),
      codeBlock("while True:"),
      codeBlock("    schedule.run_pending()"),
      codeBlock("    time.sleep(30)"),
      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 4. OUTPUTS
      // ═══════════════════════════════════════
      heading1("4. Artefatos e Outputs Gerados"),
      body("O pipeline gera automaticamente os seguintes artefatos a cada execução:"),
      ...spacer(1),
      outputsTable(),
      ...spacer(1),

      heading2("4.1 Estrutura do Relatório Excel"),
      body("O arquivo Excel é composto por 6 abas, cada uma com propósito específico:"),
      ...spacer(1),
      ...[
        ["📊 Dashboard",        "KPIs em tempo real: número de astronautas, posição da ISS, contagem de NEOs, nível de alerta da IA, score de atividade. Resumo executivo e recomendações da IA."],
        ["👨‍🚀 Astronautas",      "Lista de todos os astronautas atualmente no espaço com nome, nave e status de missão."],
        ["🚀 Missões",          "Tabela de missões espaciais ativas coletadas via web scraping com agência, destino e status."],
        ["📰 Notícias",         "Últimas notícias espaciais coletadas via API com título, resumo, fonte e URL para a matéria original."],
        ["🤖 Análise IA",       "Resultado completo da análise do Claude: resumo, alertas, tendências, insights detalhados e lista de asteroides perigosos."],
        ["☄️ Asteroides NEO",   "Objetos próximos à Terra catalogados pela NASA com diâmetro, distância de passagem e velocidade relativa. Destaque em vermelho para os potencialmente perigosos."],
      ].map(([aba, desc]) =>
        new Table({
          width: { size: 9360, type: WidthType.DXA },
          columnWidths: [2000, 7360],
          rows: [new TableRow({ children: [
            cell(aba,  { fill: DARK, bold: true, color: WHITE, width: 2000 }),
            cell(desc, { fill: LIGHT, width: 7360 }),
          ]})]
        })
      ),
      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 5. MATRIZ DE AVALIAÇÃO
      // ═══════════════════════════════════════
      heading1("5. Aderência à Matriz de Avaliação"),
      body("A tabela abaixo demonstra como o projeto atende a cada critério técnico da Global Solution 2026:"),
      ...spacer(1),
      avaliacaoTable(),
      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 6. COMO EXECUTAR
      // ═══════════════════════════════════════
      heading1("6. Instruções de Execução"),

      heading2("6.1 Pré-requisitos"),
      bullet("Python 3.10 ou superior"),
      bullet("Pip (gerenciador de pacotes Python)"),
      bullet("Chave de API gratuita da Anthropic (claude.ai/settings/keys)"),
      bullet("Opcional: chave gratuita da NASA (api.nasa.gov)"),
      ...spacer(1),

      heading2("6.2 Instalação das Dependências"),
      codeBlock("pip install -r requirements.txt"),
      ...spacer(1),

      heading2("6.3 Configuração da Chave Claude"),
      codeBlock("# Windows (Prompt de Comando)"),
      codeBlock("set ANTHROPIC_API_KEY=sua_chave_aqui"),
      codeBlock(""),
      codeBlock("# Linux / macOS"),
      codeBlock("export ANTHROPIC_API_KEY=sua_chave_aqui"),
      ...spacer(1),

      heading2("6.4 Execução"),
      codeBlock("# Execução única (gera relatório imediatamente)"),
      codeBlock("python main.py"),
      codeBlock(""),
      codeBlock("# Execução agendada (repete a cada 60 minutos automaticamente)"),
      codeBlock("python main.py --schedule 60"),
      ...spacer(1),

      heading2("6.5 Estrutura de Arquivos do Projeto"),
      codeBlock("orbital_sentinel/"),
      codeBlock("├── main.py            ← Código principal (todo o pipeline)"),
      codeBlock("├── requirements.txt   ← Dependências Python"),
      codeBlock("├── README.md          ← Instruções rápidas"),
      codeBlock("├── data/              ← JSONs de dados brutos e análise IA"),
      codeBlock("├── outputs/           ← Relatórios Excel gerados"),
      codeBlock("├── logs/              ← Arquivos de log de execução"),
      codeBlock("└── reports/           ← Pasta reservada para relatórios extras"),
      ...spacer(1),
      pageBreak(),

      // ═══════════════════════════════════════
      // 7. CONCLUSÃO
      // ═══════════════════════════════════════
      heading1("7. Conclusão"),
      body("O Orbital Sentinel demonstra na prática como a integração de múltiplos conceitos de AI for RPA resulta em um sistema robusto e inteligente. O projeto vai além do requisito mínimo de dois tópicos, combinando cinco áreas do semestre em um único pipeline coerente e funcional."),
      ...spacer(1),
      body("A arquitetura em módulos garante que cada componente possa ser testado, modificado ou substituído de forma independente — princípio fundamental da engenharia de software aplicada à automação. O tratamento de exceções em todas as camadas e o sistema de fallback asseguram que o robô nunca falhe completamente, mesmo quando APIs externas estão indisponíveis."),
      ...spacer(1),
      body("A integração do LLM (Claude) ao fluxo RPA representa a vanguarda da automação inteligente: não apenas coletar e estruturar dados, mas interpretá-los semanticamente e gerar inteligência acionável de forma autônoma — exatamente o papel que a IA desempenhará nos sistemas de automação de próxima geração."),
      ...spacer(1),

      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 480, after: 0 },
        border: { top: { style: BorderStyle.SINGLE, size: 6, color: ACCENT, space: 1 } },
        children: [new TextRun({ text: "FIAP — Global Solution 2026 | AI for RPA | Orbital Sentinel", size: 18, color: MID, italics: true, font: "Calibri" })]
      }),
    ]
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/orbital_sentinel/outputs/documentacao_orbital_sentinel.docx", buf);
  console.log("✅ Documentação Word gerada com sucesso!");
});
