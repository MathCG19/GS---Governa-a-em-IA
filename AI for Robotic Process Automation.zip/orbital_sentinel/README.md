# 🚀 ORBITAL SENTINEL
## Sistema Automatizado de Monitoramento de Missões Espaciais
**FIAP — Global Solution 2026 | AI for RPA**

---

## Como executar

### 1. Instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Configurar chave da API Claude (obrigatório para análise IA)
```bash
# Windows
set ANTHROPIC_API_KEY=sua_chave_aqui

# Linux/Mac
export ANTHROPIC_API_KEY=sua_chave_aqui
```

### 3. Executar uma vez
```bash
python main.py
```

### 4. Executar em modo agendado (a cada 60 minutos)
```bash
python main.py --schedule 60
```

---

## Saídas geradas
- `outputs/orbital_sentinel_TIMESTAMP.xlsx` — Relatório Excel completo
- `data/raw_data_TIMESTAMP.json`            — Dados brutos coletados
- `data/ai_analysis_TIMESTAMP.json`         — Análise gerada pela IA
- `logs/orbital_TIMESTAMP.log`              — Log completo da execução
