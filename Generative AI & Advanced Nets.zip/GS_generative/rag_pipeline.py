"""
rag_pipeline.py - Pipeline RAG completo para documentos espaciais
Usando OpenRouter API (compatível com OpenAI SDK)
Modelo: meta-llama/llama-3.1-8b-instruct (barato e muito bom)
"""

import os
import re
import numpy as np
from typing import List, Tuple, Optional
from dataclasses import dataclass

import fitz
import docx
from sentence_transformers import SentenceTransformer
import faiss
from openai import OpenAI


@dataclass
class DocumentChunk:
    text: str
    source: str
    chunk_id: int
    page: int = 0


class SpaceRAGPipeline:

    def __init__(
        self,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        top_k: int = 4,
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.top_k = top_k
        self.chunks: List[DocumentChunk] = []
        self.vector_store = None
        self.embeddings_matrix = None

        print("Carregando modelo de embeddings...")
        self.embedder = SentenceTransformer(embedding_model)
        try:
            self.embedding_dim = self.embedder.get_embedding_dimension()
        except AttributeError:
            self.embedding_dim = self.embedder.get_sentence_embedding_dimension()

        # Cliente OpenRouter (usa o SDK da OpenAI)
        self.llm = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=os.environ.get("OPENROUTER_API_KEY", ""),
        )
        # Modelo: llama-3.1-8b — barato (~$0.06/1M tokens) e excelente em PT-BR
        self.model = "meta-llama/llama-3.1-8b-instruct"

        print(f"Pipeline iniciado | Dim embeddings: {self.embedding_dim}")

    def read_pdf(self, path: str) -> List[Tuple[str, int]]:
        pages = []
        doc = fitz.open(path)
        for i, page in enumerate(doc):
            text = page.get_text("text").strip()
            if text:
                pages.append((text, i + 1))
        doc.close()
        return pages

    def read_txt(self, path: str) -> List[Tuple[str, int]]:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [(f.read(), 1)]

    def read_docx(self, path: str) -> List[Tuple[str, int]]:
        doc = docx.Document(path)
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        return [(text, 1)]

    def read_document(self, path: str) -> List[Tuple[str, int]]:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".pdf":
            return self.read_pdf(path)
        elif ext == ".txt":
            return self.read_txt(path)
        elif ext in (".docx", ".doc"):
            return self.read_docx(path)
        else:
            raise ValueError(f"Formato não suportado: {ext}")

    def split_text(self, text: str) -> List[str]:
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r' {2,}', ' ', text)
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        chunks = []
        current_chunk = ""

        for para in paragraphs:
            if len(para) > self.chunk_size:
                sentences = re.split(r'(?<=[.!?])\s+', para)
                for sent in sentences:
                    if len(current_chunk) + len(sent) <= self.chunk_size:
                        current_chunk += " " + sent
                    else:
                        if current_chunk.strip():
                            chunks.append(current_chunk.strip())
                        current_chunk = sent
            else:
                if len(current_chunk) + len(para) <= self.chunk_size:
                    current_chunk += "\n\n" + para
                else:
                    if current_chunk.strip():
                        chunks.append(current_chunk.strip())
                    overlap_text = current_chunk[-self.chunk_overlap:] if self.chunk_overlap else ""
                    current_chunk = overlap_text + "\n\n" + para

        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        return chunks

    def add_document(self, path: str) -> str:
        filename = os.path.basename(path)
        try:
            pages = self.read_document(path)
        except Exception as e:
            return f"❌ Erro ao ler {filename}: {e}"

        doc_chunks = []
        for text, page_num in pages:
            splits = self.split_text(text)
            for split in splits:
                if len(split) > 30:
                    chunk = DocumentChunk(
                        text=split,
                        source=filename,
                        chunk_id=len(self.chunks) + len(doc_chunks),
                        page=page_num,
                    )
                    doc_chunks.append(chunk)

        self.chunks.extend(doc_chunks)
        return f"📄 {filename}: {len(doc_chunks)} chunks criados (de {len(pages)} página(s))"

    def build_index(self):
        if not self.chunks:
            return

        texts = [c.text for c in self.chunks]
        print(f"Gerando embeddings para {len(texts)} chunks...")
        embeddings = self.embedder.encode(
            texts,
            batch_size=32,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )

        self.embeddings_matrix = embeddings.astype("float32")
        self.vector_store = faiss.IndexFlatIP(self.embedding_dim)
        self.vector_store.add(self.embeddings_matrix)
        print(f"Indice FAISS construido: {self.vector_store.ntotal} vetores")

    def retrieve(self, question: str) -> List[DocumentChunk]:
        q_emb = self.embedder.encode(
            [question],
            normalize_embeddings=True,
            convert_to_numpy=True,
        ).astype("float32")

        scores, indices = self.vector_store.search(q_emb, self.top_k)
        retrieved = []
        for idx, score in zip(indices[0], scores[0]):
            if idx < len(self.chunks) and score > 0.05:
                retrieved.append(self.chunks[idx])
        return retrieved

    def build_prompt(self, question: str, context_chunks: List[DocumentChunk]) -> str:
        context_parts = []
        for i, chunk in enumerate(context_chunks, 1):
            context_parts.append(
                f"[Fonte {i}: {chunk.source} - Página {chunk.page}]\n{chunk.text}"
            )
        context = "\n\n---\n\n".join(context_parts)

        return f"""Você é um assistente especializado na nova economia espacial, cobrindo temas como:
- Clima e meteorologia por satélite
- Sensoriamento remoto e observação da Terra
- Agricultura de precisão com tecnologia espacial
- Monitoramento ambiental
- Desastres naturais e alertas precoces
- Exploração e missões espaciais

Use APENAS as informações dos documentos fornecidos para responder.
Se a resposta não estiver nos documentos, diga claramente que não encontrou essa informação.
Responda sempre em português brasileiro de forma clara, técnica e organizada.

=== DOCUMENTOS RECUPERADOS ===

{context}

=== PERGUNTA ===
{question}

=== RESPOSTA ==="""

    def query(self, question: str) -> str:
        relevant_chunks = self.retrieve(question)

        if not relevant_chunks:
            return (
                "❌ Não encontrei informações relevantes nos documentos carregados.\n\n"
                "Tente reformular a pergunta ou faça upload de documentos mais relacionados ao tema."
            )

        prompt = self.build_prompt(question, relevant_chunks)

        response = self.llm.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": "Você é um assistente especializado na nova economia espacial. Responda sempre em português brasileiro."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=1024,
            extra_headers={
                "HTTP-Referer": "http://localhost:7860",
                "X-Title": "Space RAG Assistant",
            }
        )
        answer = response.choices[0].message.content

        sources = list({f"📄 {c.source} (p. {c.page})" for c in relevant_chunks})
        sources_str = "\n".join(sources)

        return f"{answer}\n\n---\n**Fontes consultadas:**\n{sources_str}"

    def clear(self):
        self.chunks = []
        self.vector_store = None
        self.embeddings_matrix = None
        print("Indice limpo.")
