import os
import gradio as gr
from rag_pipeline import SpaceRAGPipeline

pipeline = SpaceRAGPipeline()

def process_documents(files, progress=gr.Progress()):
    if not files:
        return "Nenhum arquivo enviado."
    progress(0.1, desc="Lendo documentos...")
    results = []
    for file in files:
        result = pipeline.add_document(file.name)
        results.append(result)
    progress(0.9, desc="Indexando embeddings...")
    pipeline.build_index()
    progress(1.0, desc="Concluido!")
    return "\n".join(results) + f"\n\n {len(files)} documento(s) indexado(s) com sucesso!"

def answer_question(question, history):
    if not question.strip():
        return history, ""
    if pipeline.vector_store is None or len(pipeline.chunks) == 0:
        response = "Nenhum documento indexado. Faca upload de documentos primeiro."
    else:
        response = pipeline.query(question)
    if history is None:
        history = []
    history = history + [
        {"role": "user", "content": question},
        {"role": "assistant", "content": response},
    ]
    return history, ""

def clear_index():
    pipeline.clear()
    return "Indice limpo com sucesso."

with gr.Blocks(title="Space RAG Assistant") as demo:

    gr.HTML("""
    <div style="text-align:center;padding:20px;background:linear-gradient(135deg,#0a0a2e,#1a1a5e);border-radius:10px;color:white;margin-bottom:20px;">
        <h1>Space RAG Assistant</h1>
        <p>Assistente Inteligente para Dados e Documentos da Nova Economia Espacial</p>
        <small>Matheus Cardoso (RM 564898) | Caique Sousa (RM 563621) | FIAP - IA</small>
    </div>
    """)

    with gr.Tabs():
        with gr.TabItem("Documentos"):
            gr.Markdown("### Faca upload de documentos (PDF, TXT, DOCX)")
            with gr.Row():
                with gr.Column(scale=2):
                    file_input = gr.File(
                        label="Selecionar Arquivos",
                        file_types=[".pdf", ".txt", ".docx"],
                        file_count="multiple"
                    )
                    with gr.Row():
                        upload_btn = gr.Button("Processar Documentos", variant="primary")
                        clear_btn = gr.Button("Limpar Indice", variant="secondary")
                with gr.Column(scale=1):
                    status_output = gr.Textbox(label="Status", lines=8, placeholder="Aguardando documentos...")

            upload_btn.click(process_documents, inputs=[file_input], outputs=[status_output])
            clear_btn.click(clear_index, outputs=[status_output])

        with gr.TabItem("Perguntar"):
            gr.Markdown("### Faca perguntas sobre os documentos indexados")

            chatbot = gr.Chatbot(label="Space RAG Chat", height=450)

            with gr.Row():
                question_input = gr.Textbox(
                    label="Sua pergunta",
                    placeholder="Ex: O que e monitoramento climatico por satelite?",
                    scale=4
                )
                send_btn = gr.Button("Enviar", variant="primary", scale=1)

            gr.Examples(
                examples=[
                    ["Quais sao os principais satelites de monitoramento climatico?"],
                    ["Como a IA e usada na agricultura de precisao espacial?"],
                    ["Quais desastres naturais podem ser monitorados por satelite?"],
                ],
                inputs=question_input
            )

            send_btn.click(answer_question, inputs=[question_input, chatbot], outputs=[chatbot, question_input])
            question_input.submit(answer_question, inputs=[question_input, chatbot], outputs=[chatbot, question_input])

        with gr.TabItem("Sobre"):
            gr.Markdown("""
            ## Arquitetura do Sistema

            | Componente | Tecnologia |
            |-----------|-----------|
            | Embeddings | sentence-transformers (all-MiniLM-L6-v2) |
            | Vector Store | FAISS |
            | LLM | Llama 3.1 8B via OpenRouter |
            | Interface | Gradio |

            ### Grupo
            - Matheus Cardoso - RM 564898
            - Caique Sousa - RM 563621
            - Curso: Inteligencia Artificial - FIAP 2026
            """)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860, show_error=True)
