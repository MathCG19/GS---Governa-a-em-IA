# 🚀 Space RAG Assistant

**Assistente Inteligente com RAG para Dados e Documentos Espaciais**

> Global Solution — Inteligência Artificial Generativa | FIAP 2026

**Grupo:**
- Matheus Cardoso — RM 564898
- Caique Sousa — RM 563621

---

## 📌 Descrição

Sistema de perguntas e respostas baseado em **RAG (Retrieval-Augmented Generation)** para documentos da nova economia espacial. O assistente indexa documentos (PDF, TXT, DOCX) sobre temas como clima, satélites, agricultura de precisão e exploração espacial, e responde perguntas baseando-se no conteúdo real dos documentos.

---

## 🏗️ Arquitetura

```
┌─────────────────────────────────────────────────────────┐
│                    FASE DE INDEXAÇÃO                     │
│                                                         │
│  Documento  →  Leitura  →  Chunking  →  Embedding       │
│  (PDF/TXT/     (fitz /      (500 chars   (sentence-      │
│   DOCX)        python-      + overlap)   transformers)   │
│                docx)                         ↓           │
│                                         FAISS Index      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                    FASE DE CONSULTA                      │
│                                                         │
│  Pergunta → Embedding → Busca FAISS → Top-K Chunks      │
│     do        (mesmo                      ↓             │
│  usuário       modelo)              Prompt + Contexto    │
│                                          ↓              │
│                              Claude Haiku (LLM)          │
│                                          ↓              │
│                                    Resposta Final        │
└─────────────────────────────────────────────────────────┘
```

## ⚙️ Componentes Técnicos

| Componente | Tecnologia | Justificativa |
|-----------|-----------|---------------|
| Embeddings | `sentence-transformers/all-MiniLM-L6-v2` | Leve, rápido, multilingue |
| Vector Store | `FAISS (IndexFlatIP)` | Alta performance, local, sem custo |
| LLM | `Claude Haiku (Anthropic)` | Custo baixo, contexto grande |
| Chunking | Recursivo por parágrafo + tamanho | Preserva coerência semântica |
| Leitura PDF | `PyMuPDF (fitz)` | Robusto para PDFs científicos |
| Interface | `Gradio` | Rápido de construir, intuitivo |

---

## 🚀 Como Executar

### 1. Clonar e instalar dependências

```bash
git clone https://github.com/seu-usuario/space-rag
cd space-rag
pip install -r requirements.txt
```

### 2. Configurar a chave da API Anthropic

```bash
export ANTHROPIC_API_KEY="sua_chave_aqui"
```

### 3. Executar a aplicação

```bash
python app.py
```

Acesse em: `http://localhost:7860`

---

## 📂 Estrutura do Projeto

```
space-rag/
├── app.py              # Interface Gradio e ponto de entrada
├── rag_pipeline.py     # Pipeline RAG completo
├── requirements.txt    # Dependências Python
├── README.md           # Este arquivo
└── data/               # Exemplos de documentos espaciais
    ├── nasa_climate.txt
    ├── agricultura_satelite.txt
    └── monitoramento_ambiental.txt
```

---

## 📊 Exemplos de Documentos para Testar

- [NASA Earth Observatory](https://earthobservatory.nasa.gov/)
- [INPE - Monitoramento de Queimadas](https://queimadas.dgi.inpe.br/)
- [ESA - Copernicus Programme](https://www.copernicus.eu/en/documentation)
- [EMBRAPA - Agricultura de Precisão](https://www.embrapa.br/agricultura-digital)

---

## ⚠️ Limitações

- Sem persistência entre sessões (índice em memória)
- Suporte apenas a PT-BR e EN nos embeddings
- Limite de contexto do LLM pode truncar documentos muito grandes
- FAISS não persiste em disco (necessário reindexar ao reiniciar)

## 🔮 Melhorias Futuras

- Persistência do índice em disco com `faiss.write_index()`
- Reranking com cross-encoder para maior precisão
- Suporte a imagens e tabelas em PDFs
- Deploy em nuvem (HuggingFace Spaces ou Render)
- Histórico de conversas com memória contextual
